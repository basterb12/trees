#' Area-to-point kriging interpolation / Kriging-Interpolation von Mischproben
#'
#' Dieses R-Package implementiert Kriging fuer die raeumliche Interpolation 
#' von Mischstichproben auf die Punktebene, beispielsweise Punktraster. Die zugrunde
#' liegende geostatistische Theorie zur Loesung des Traegerwechselproblems
#' (change-of-support problem) wird unter anderem durch Cressie (1993) beschrieben.
#' Dieses Package wurde in Auftragsarbeit fuer Agri Con GmbH, Jahna, Deutschland
#' durch Alexander Brenning und Jotham Apaloo, University of Waterloo, Ontario,
#' Kanada entwickelt.
#'
#' @references Cressie, N.A.C., 1993. Statistics for Spatial Data. Wiley Series in Probability and Statistics.
#' 
#' @docType package
#' @name atopkrige-package
#' @aliases atopkrige-package
NULL
