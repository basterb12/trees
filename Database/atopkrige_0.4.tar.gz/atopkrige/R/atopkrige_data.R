# Describe the data set:

#' Beispieldatensatz Gruenholz
#'
#' @name gruenholz
#' @docType data
#' @format Ein \code{data.frame} mit Beobachtungsdaten der Felder 8-0 und 6-0 der 
#' Herzoglichen Gutsverwaltung Gruenholz, Schleswig-Holstein, fuer Testzwecke.
NULL



#' Beispieldatensatz Gruenholz: Interpolationspunkte
#'
#' @name gruenholzpred
#' @docType data
#' @format Ein \code{data.frame} mit Punktkoordinaten auf einem 20 m x 20 m 
#' Punktraster im Bereich des Datensatzes \code{\link{gruenholz}}.
NULL



# Describe the data set:

#' Beispieldatensatz Gruenholz 2
#'
#' @name gruenholz2
#' @docType data
#' @format Ein \code{data.frame} mit Beobachtungsdaten der Felder 38-0, 154-0, 83-0 und 10-0 der 
#' Herzoglichen Gutsverwaltung Gruenholz, Schleswig-Holstein, fuer Testzwecke.
NULL



#' Beispieldatensatz Gruenholz 2: Interpolationspunkte
#'
#' @name gruenholz2pred
#' @docType data
#' @format Ein \code{data.frame} mit Punktkoordinaten auf einem 20 m x 20 m 
#' Punktraster im Bereich des Datensatzes \code{\link{gruenholz2}}.
NULL
