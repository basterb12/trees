
#' Sphaerisches Semivariogram auf Punktebene
#'
#' \code{svgm} berechnet die paarweisen sphaerischen Semivarianzen der durch die Argumente 
#' \code{x1} und \code{x2} gegebenen Punktepaare.
#' @name svgm
#' @param x1 Ein \code{data.frame}, der mindestens (in den durch \code{xy.names} 
#'       angegebenen Spalten) x/y-Punktkoordinaten enthaelt. Dieses Argument definiert
#'       die ersten Punkte der Punktepaare (siehe jedoch \code{x2}).
#' @param x2 Ein optionaler zweiter \code{data.frame}, der die zweiten Punkte der
#'       Punktepaare definiert. Wenn \code{NULL}, so wird \code{x2=x1} gewaehlt.
#' @param psill Partieller Sill-Parameter des sphaerischen Semivariogramms, d.h. der
#'       Sill ohne Nugget-Effekt.
#' @param range.est Autokorrelationsweite (Range-Parameter) des sphaerischen Semivariogramms.
#' @param nugget Nugget-Semivarianz des sphaerischen Semivariogramms.
#' @param xy.names Namen der die x- und y-Koordinaten enthaltenden Spalten in \code{x1} und \code{x2}
#' @return Eine Semivariogramm-Matrix mit \code{nrow(x1)} Zeilen und \code{nrow(x2)} 
#'      Spalten. 
#' @details Element \code{[i,j]} des Ergebnisses enthaelt die sphaerische Semivarianz zwischen 
#'      dem \code{i}-ten Punkt in \code{x1} und dem \code{j}-ten Punkt in \code{x2}.
#'      Die hier festgelegten Semivariogramm-Parameter sind die Parameter des Punkt-zu-Punkt-Semivariogramms.
#'      diese sind NICHT durch empirische Semivariogramm-Modellierung auf Mischstichproben-Ebene zu
#'      schaetzen - dies wuerde verzerrte Schaetzungen ergeben.
#' @seealso \code{\link{svgm.sum}}, \code{\link{svgm.sum2}}; \code{vgm} in package \code{gstat}
#' @export
svgm = function(x1, x2 = x1, psill=1, range.est=500, nugget=0.5, xy.names=c("x", "y"))
{
    #calculate the pairwise distances for use in the pairwise semivariogram calculation
    m = sqrt( outer(x1[,xy.names[1]],x2[,xy.names[1]],"-")^2 + 
              outer(x1[,xy.names[2]],x2[,xy.names[2]],"-")^2 ) 
    
    #create empty output matrix of pairwaise spherical semivariogram values
    result = matrix(NA, nrow(m), ncol(m))
    
    #fill the pairwise semivariogram matrix (currently using the spherical semivariogram model)
    #if the points are closer than the range distance
    sel = m < range.est
    result[ sel ] = nugget + psill * (((3*m[sel])/(2*range.est) - (m[sel]^3)/(2*range.est^3)))
    #if the points are further than the range distance
    result[ m >= range.est ] = nugget + psill
    #if distance equals 0:
    result[ m == 0 ] = 0    
    
    return(result)
}



#' Sphaerisches Semivariogramm integriert ueber die Traegerpunkte der Mischstichproben.
#'
#' \code{svgm.sum} integriert das durch \code{\link{svgm}} berechnete sphaerische
#'       Semivariogramm bezueglich seines zweiten Arguments, um ein 
#'       Punkt-zu-Mischstichproben-Semivariogramm zu erhalten.
#' @name svgm.sum
#' @inheritParams svgm
#' @param x2 Ein zweiter \code{data.frame}, der die zweiten Punkte der
#'       Punktepaare definiert.
#' @param groups2 Name der Faktor-Variable in \code{x2}, die die Zugehoerigkeit
#'       von Punkten zu Mischstichproben festlegt. Punkte in \code{x2}, die denselben
#'       Wert in \code{groups2} haben, werden als eine Mischstichprobe angesehen.
#' @param ... Optionale weitere Argumente, die an \code{\link{svgm}} weitergereicht werden.
#' @return Eine Punkt-zu-Mischstichproben-Semivariogramm-Matrix mit \code{nrow(x1)} 
#'      Zeilen und \code{nlevels(x2[,groups2])} Spalten. 
#' @details Element \code{[i,j]} des Ergebnisses enthaelt die sphaerische Punkt-zu-Mischstichproben-Semivarianz 
#'      zwischen dem \code{i}-ten Punkt in \code{x1} und der \code{j}-ten Mischstichprobe 
#'      in \code{x2}. Diese Semivarianz entsteht durch Mittelung, d.h. numerische Integration,
#'      der durch \code{svgm} berechneten sphaerischen Semivarianz.
#' @seealso \code{\link{svgm}}, \code{\link{svgm.sum2}}
#' @export
svgm.sum = function(x1, x2, groups2, ...)
{
    #if ("SpatialPointsDataFrame" %in% class(x1)) x1 = as.data.frame(x1)
    #if ("SpatialPointsDataFrame" %in% class(x2)) x2 = as.data.frame(x2)
    #if (missing(groups2)) stop("groups2 Argument fehlt in svgm.sum")

    #convert group variable to factor
    grp2 = as.factor(x2[,groups2])
    lev2 = levels(grp2)
    
    #create the pairwise semivariogram matrix
    m = svgm(x1=x1, x2=x2, ...)
    
    #fill it for each point (rows) with the mean semivariogram value of the group (resulting columns)
    if (nrow(m)==1) {
        result = matrix( tapply(m, grp2, mean), 1 )
        #result = matrix(NA, nrow(m), nlevels(grp2))
        #for(i in 1:nlevels(grp2))
        #    result[,i] = mean(m[,grp2==lev2[i]])
    } else { 
        #create the matrix to fill with the group averaged semivariogram values
        result = matrix(NA, nrow(m), nlevels(grp2))
        for(i in 1:nlevels(grp2))
            result[,i] =  apply(m[,grp2==lev2[i]], 1, mean)
    }
    
    return(result)
}


#' Semivarianz zwischen Mischstichproben
#'
#' \code{svgm.sum2} berechnet zweifach integrierte Semivarianzen, d.h. Semivarianzen
#'       zwischen Paaren von Mischstichproben.
#' @name svgm.sum2
#' @inheritParams svgm.sum
#' @param groups1, groups2 Namen der Faktor-Variablen in \code{x1} bzw. \code{x2}, 
#'       die die Zugehoerigkeit von Punkten zu Mischstichproben festlegt.
#'       Punkte in \code{x1}, zum Beispiel, die denselben
#'       Wert in \code{groups1} aufweisen, werden als eine Mischstichprobe angesehen.
#' @param ... Optionale weitere Argumente, die an \code{\link{svgm.sum}} und 
#'       letztlich \code{\link{svgm}} weitergereicht werden.
#' @return Eine Punkt-zu-Mischstichproben-Semivariogramm-Matrix mit \code{nrow(x1)} 
#'      Zeilen und \code{nlevels(x2[,groups2])} Spalten. 
#' @details Element \code{[i,j]} des Ergebnisses enthaelt die sphaerische Punkt-zu-Mischstichproben-Semivarianz 
#'      zwischen dem \code{i}-ten Punkt in \code{x1} und der \code{j}-ten Mischstichprobe 
#'      in \code{x2}. Diese Semivarianz entsteht durch Mittelung, d.h. numerische Integration,
#'      der durch \code{svgm} berechneten sphaerischen Semivarianz.
#' @seealso \code{\link{svgm}}, \code{\link{svgm.sum}}
#' @export
svgm.sum2 = function(x1, x2=x1, groups1, groups2=groups1, ...)
{
    #if ("SpatialPointsDataFrame" %in% class(x1)) x1 = as.data.frame(x1)
    #if ("SpatialPointsDataFrame" %in% class(x2)) x2 = as.data.frame(x2)
    #if (missing(groups1)) stop("groups1 Argument in fehlt in svgm.sum2")

    #factorize the group variables
    grp1 = as.factor(x1[,groups1])
    grp2 = as.factor(x2[,groups2])
    lev1 = levels(grp1)
    lev2 = levels(grp2)
    
    #create the output matrix
    result = matrix(NA, nlevels(grp1), nlevels(grp2))
    
    #compute the point-group averaged semivariogram values
    m = svgm.sum(x1=x1, x2=x2, groups2=groups2, ...)
    #average the point-group semivariogram values across the points of each group
    for(i in 1:nrow(result)){
        result[i,] =  apply( m[grp1==lev1[i],], 2, mean )
    }

    return(result)
}


#' gamma-Vektor des Kriging-Gleichungssystems
#'
#' \code{gammavec} erzeugt den gamma-Vektor des Kriging-Gleichungssystems
#'      aus einem Vektor (bzw. Matrix als Sammlung solcher Vektoren) der
#'      Semivarianzen (hier: der Punkt-zu-Mischstichproben-Semivarianzen).
#' @name gammavec
#' @param x Eine durch \code{\link{svgm.sum}} berechnete Matrix, die in 
#'       jeder Zeile einen gamma-Vektor enthaelt.
#' @return Die Matrix \code{x} mit einer zusaetzlichen Spalte, die mit Einsen
#'       besetzt ist. (Siehe Kriging-Gleichungssystem in Cressie, 1993.)
#' @seealso \code{\link{svgm.sum}}, \code{\link{Gamma}}
#' @export
gammavec = function(x){
    return(cbind(x, rep(1, nrow(x))))
}


#' Gamma-Matrix des Kriging-Gleichungssystems
#'
#' \code{Gamma} erzeugt die Gamma-Matrix des Kriging-Gleichungssystems
#'      aus einer Matrix der Semivarianzen zwischen Beobachtungspunkten
#'      bzw. im Falle des Area-to-point-Krigings einer Matrix der Semivarianzen
#'      zwischen Mischstichproben.
#' @name Gamma
#' @param x Eine durch \code{\link{svgm.sum2}} berechnete Matrix.
#' @return Die Matrix \code{x} mit einer zusaetzlichen Spalte und Zeile, die 
#'       jeweils mit Einsen besetzt sind, mit Ausnahme der unteren rechten Ecke, 
#'       die mit einer Null besetzt ist. (Siehe Kriging-Gleichungssystem 
#'       in Cressie, 1993.)
#' @seealso \code{\link{svgm.sum2}}, \code{\link{gammavec}}
#' @export
Gamma = function(x){
    #add colum and row of ones to the svgm.sum2 and 0 at [n,n] to satisfy conditions for qr.solve
    return(rbind(cbind(x, rep(1, nrow(x))), c(rep(1, ncol(x)), 0)))
}


#' Kriging-Interpolation von Mischproben
#'
#' \code{AtoP.krige} implementiert Kriging fuer die raeumliche Interpolation 
#' von Mischstichproben auf die Punktebene, beispielsweise Punktraster.
#' @name AtoP.krige
#' @param data Ein \code{data.frame} mit der zu interpolierenden Variable, einer
#'       Gruppenvariable zur Identifikation der Mischstichproben, und Variablen, die
#'       die x- und y-Koordinaten der Einzelpunkte festlegen.
#' @param response Name der zu interpolierenden Variable in \code{data}
#' @param groups1 Name der Faktor-Variable in \code{data}, die die Zugehoerigkeit
#'       von Punkten zu Mischstichproben festlegt. Punkte in \code{data}, die denselben
#'       Wert in \code{groups1} haben, werden als eine Mischstichprobe angesehen.
#' @param newdata Ein \code{data.frame}, der die Koordinaten der Zielpunkte der
#'       Interpolation enthaelt. (Da es sich um eine Interpolation auf einen Punkttraeger
#'       handelt, wird im Gegensatz zu \code{data} keine Gruppierung festgelegt.)
#' @param xy.names Namen der die x- und y-Koordinaten enthaltenden Spalten in \code{data} und \code{newdata}
#' @param trace Eine Zahl, die bestimmt, wie detailliert auf dem Bildschirm (bzw. \code{stdout()})
#'       ueber den Interpolationsfortschritt berichtet werden soll. \code{trace<0} unterdrueckt
#'       jegliche Ausgabe, \code{trace>=0} gibt eine Anfangsmeldung aus,
#'       \code{trace>=1} zeigt detaillierte Fortschrittsangaben an (z.B. ein \code{"."} fuer jeden
#'       zehnten interpolierten Punkt).
#' @param ... Weitere erforderliche sowie optionale Argumente, die an
#'       \code{\link{svgm.sum}} und \code{\link{svgm.sum2}} sowie
#'       letztlich an \code{\link{svgm}} weitergereicht werden. Hierin sind
#'       insbesondere die Semivariogramm-Parameter enthalten (siehe \code{\link{svgm}}).
#'       Im Falle von \code{AtoP.krige.int} und \code{AtoP.krige.S} Argumente, die an \code{AtoP.krige} weitergegeben werden.
#' @return Eine um zwei Spalten \code{var1.pred} und \code{var1.var} erweiterte
#'       Kopie von \code{newdata}. Die zusaetzlichen Variablen enthalten die
#'       Kriging-Interpolation bzw. die Kriging-Varianz.
#' @details Waehrend die Funktion \code{AtoP.krige} 'gewoehnliches' Kriging fuer
#'      Mischstichproben durchfuehrt, kriget \code{AtoP.krige.S} logistisch transformierte
#'      Daten, um auf diese Weise sicherzustellen, dass der vorgegebene Wertebereich
#'      nicht ueberschritten wird. \code{AtoP.krige.int} ist fuer die Interpolation
#'      von ganzzahligen Variablen optimiert und beruht auf \code{AtoP.krige.S}.
#' 
#'      Die eigentuemlichen Variablennamen \code{var1.pred} und \code{var1.var} im Ergebnis-Objekt
#'       wurden aus Kompatibilitaetsgruenden so von \code{krige} in \code{gstat}
#'       uebernommen. Kriging-Varianz ist im Falle von \code{AtoP.krige.S} und \code{.int} am besten
#'       zu ignorieren, bei \code{AtoP.krige} zumindest mit Vorsicht zu geniessen, da die
#'       vorhandenen Daten keine verlaessliche Anpassung des Semivariogramms zulassen.
#'
#'       Mischstichproben muessen aus mindestens zwei Einzelpunkten bestehen, und
#'       fuer jeden Einzelpunkt muss derselbe \code{response}-Wert in \code{data[,response]}
#'       enthalten sein.
#' @references Cressie, N.A.C., 1993. Statistics for Spatial Data. Wiley Series in Probability and Statistics.
#' @seealso \code{\link{svgm.sum}}, \code{\link{svgm.sum2}}; \code{krige} im \code{gstat}-Package
#' @examples 
#' \dontrun{
#' data(gruenholz)
#' data(gruenholzpred)
#' krg = AtoP.krige(data=gruenholz, response="K", groups1="GPS_NR", 
#'          newdata=gruenholzpred, xy.names=c("x","y"), 
#'          range.est = 500, psill = 0.5, nugget = 0.5)
#' palette(rainbow(100))
#' stdz = function(x) (x-min(x))/diff(range(x))
#' col = round(100 * stdz(krg$var1.pred))
#' plot(gruenholzpred$x, gruenholzpred$y, pch=19, col=col,
#'          main = "area-to-point kriging predictions", xlab="x", ylab="y")
#' points(gruenholz$x, gruenholz$y, pch="+", col="black")
#' }
#' @export
AtoP.krige = function(data, response, groups1, newdata = data, 
    xy.names = c("x","y"), trace = 0, ...)
{
    stopifnot(is.data.frame(data))
    stopifnot(is.data.frame(newdata))
    if (missing(groups1)) stop("groups1 Argument fehlt")
    stopifnot(groups1 %in% names(data))
    if (missing(response)) stop("response Argument fehlt")
    stopifnot(response %in% names(data))
    stopifnot(length(xy.names)==2)
    stopifnot(all(xy.names %in% names(data)))

    grp1 = as.factor(data[,groups1])

    #check if groups1 is a valid grouping variable:
    if (any(tapply(grp1, grp1, length) == 1)) {
        stop(groups1, " doesn't appear to be a valid grouping variable:\nSome or all bulk samples consist of only one point location,\ni.e. they are point samples not bulk samples.\n")
    }
    #my.sd = function(x) ifelse(length(x)>1, sd(x), 0)
    if (any(tapply(data[,response], grp1, sd) / mean(data[,response]) > 1e-6)) {
        stop(groups1, " doesn't appear to be a valid grouping variable:\nThe response varies within its factor levels.\n")
    }
    obs = tapply(data[,response], grp1, mean)[]

    if (trace >= 0) cat("--- Area-to-point kriging ---\n")

    if (trace >= 1) cat("Calculating area-to-area semivariogram...\n")
    g = svgm.sum2(x1=data, groups1=groups1, xy.names=xy.names, ...)
    # we can do the QR decomposition outside the for loop:
    qrG = qr( Gamma(g) )
    
    #names of kriging prediction and kriging variance variables as in krige, for consistency:
    predvar = "var1.pred"
    varvar = "var1.var"
    newdata[,predvar] = newdata[,varvar] = rep(NA,nrow(newdata))
    
    if (trace >= 1) cat("Performing area-to-point kriging...\n")

    for(i in 1:nrow(newdata)){
        if (trace >= 1) {
            if (i/10==round(i/10)) {
                cat(".")
                if (i/200==round(i/200)) 
                    cat("\n")
            }
        }
        #calculate the semivariogram values for the prediction location
        l = svgm.sum(x1=newdata[i,], x2=data, groups2=groups1, xy.names=xy.names, ...)
        L = t(gammavec(l))
        lambda = qr.solve(qrG, L)
        newdata[i,predvar] = sum( obs * lambda[-length(lambda)] )
        newdata[i, varvar] = as.vector(lambda) %*% L
    }
    if ((trace >= 1) & (i/25!=round(i/25))) cat("\n")
    return(newdata)
}



#' @rdname AtoP.krige
#' @name AtoP.krige.S
#' @param offset Betrag, um den die Spannweite von \code{minx} bis \code{maxx} nach oben und unten erweitert werden soll
#' @param minx (optionaler) Mindestwert fuer die Variable \code{response}; Voreinstellung: Minimum der \code{response}-Werte
#' @param maxx (optionaler) Hoechstwert fuer die Variable \code{response}; Voreinstellung: Maximum der \code{response}-Werte
#' @param ... weitere Argumente fuer \code{AtoP.krige}
#' @export
AtoP.krige.S <- function(data, response, offset = 0.001, minx, maxx, ...) {
  if (missing(minx)) 
    minx <- min(data[,response]) - offset
  if (missing(maxx)) 
    maxx <- max(data[,response]) + offset
  stopifnot(maxx > minx)
  data[,response] <- (data[,response] - minx) / (maxx - minx)
  data[,response] <- log( data[,response] / (1 - data[,response]) )
  krg <- AtoP.krige(data = data, response = response, ...)
  krg$var1.pred <- 1 / (1 + exp(-krg$var1.pred))
  krg$var1.pred <- krg$var1.pred * (maxx - minx) + minx
  return(krg)
}


#' @rdname AtoP.krige
#' @name AtoP.krige.int
#' @inheritParams AtoP.krige.S
#' @export
AtoP.krige.int <- function(data, response, offset = 0.499, ...) {
  krg <- AtoP.krige.S(data = data, response = response, offset= offset, ...)
  krg$var1.pred <- round(krg$var1.pred)
  return(krg)
}




#' Kriging-Interpolation von Mischproben
#'
#' \code{sp.AtoP.krige} ist ein wrapper fuer \code{\link{AtoP.krige}}, der \code{"SpatialPointsDataFrame"} Objekte bedient. Entsprechend sind \code{sp.AtoP.krige.int} bzw. \code{sp.AtoP.krige.S} wrapper fuer \code{\link{AtoP.krige.int}} bzw. \code{\link{AtoP.krige.S}}.
#' @name sp.AtoP.krige
#' @param data Ein \code{SpatialPointsDataFrame} mit der zu interpolierenden Variable und einer
#'       Gruppenvariable zur Identifikation der Mischstichproben.
#'       x- und y-Koordinaten der Einzelpunkte sind implizit in den raeumlichen Attributen
#'       enthalten; Projektion nach UTM Zone 32 wird automatisch durchgefuehrt.
#' @param newdata Ein \code{SpatialPointsDataFrame} mit Zielpunkten.)
#' @param xy.names Namen der Spalten, in denen die berechneten x- und y-UTM-Koordinaten in \code{data} und \code{newdata} abgespeichert werden
#' @param proj Zeichenkette mit Projektionsargumenten, wie in Funktion \code{project} in package \code{rgdal} spezifiziert.
#'        Voreinstellung \code{"+proj=utm +zone=32"}, d.h. Projektion nach UTM Zone 32.
#' @param ... Weitere erforderliche sowie optionale Argumente -- siehe \code{\link{AtoP.krige}}, \code{\link{AtoP.krige.int}}, \code{\link{AtoP.krige.S}}.
#' @return Wie in \code{\link{AtoP.krige}}, aber als \code{SpatialPointsDataFrame} mit der in \code{proj} angegebenen Projektion.
#' @seealso \code{\link{svgm.sum2}}; \code{project} im \code{rgdal}-Package
#' @export
sp.AtoP.krige = function(data, newdata = data, 
    xy.names = c("x","y"), proj = "+proj=utm +zone=32", ...)
{
    require(sp)
    require(rgdal)
    #only this object class is accepted as an input:
    stopifnot("SpatialPointsDataFrame" %in% class(data))
    stopifnot("SpatialPointsDataFrame" %in% class(newdata))

    #conversion and projection function:
    sp.to.df = function(d,xnm,ynm,proj) {
        #convert the lat/lon coordinates to UTM
        prj = project(cbind(coordinates(d)[,1], coordinates(d)[,2]), proj=proj)
        d = as.data.frame(d)
        #add UTM coordinates to the spatial data frame
        d[,xnm] = prj[,1]
        d[,ynm] = prj[,2]
        return(d)
    }

    #convert to data.frame, and project to proj:
    data = sp.to.df(data, xnm=xy.names[1], ynm=xy.names[2], proj=proj)
    newdata = sp.to.df(newdata, xnm=xy.names[1], ynm=xy.names[2], proj=proj)
    
    #let AtoP.krige do the actual work:
    res = AtoP.krige(data=data, newdata=newdata, xy.names=xy.names, ...)
    
    #convert back to SpatialPointsDataFrame, but without inverting the projection (sorry):
    coordinates(res) = as.formula( paste("~", xy.names[1], "+", xy.names[2]) )
    
    return( res )
}




#' @rdname sp.AtoP.krige
#' @name sp.AtoP.krige.int
#' @export
sp.AtoP.krige.int = function(data, newdata = data, 
                         xy.names = c("x","y"), proj = "+proj=utm +zone=32", ...)
{
  require(sp)
  require(rgdal)
  #only this object class is accepted as an input:
  stopifnot("SpatialPointsDataFrame" %in% class(data))
  stopifnot("SpatialPointsDataFrame" %in% class(newdata))
  
  #conversion and projection function:
  sp.to.df = function(d,xnm,ynm,proj) {
    #convert the lat/lon coordinates to UTM
    prj = project(cbind(coordinates(d)[,1], coordinates(d)[,2]), proj=proj)
    d = as.data.frame(d)
    #add UTM coordinates to the spatial data frame
    d[,xnm] = prj[,1]
    d[,ynm] = prj[,2]
    return(d)
  }
  
  #convert to data.frame, and project to proj:
  data = sp.to.df(data, xnm=xy.names[1], ynm=xy.names[2], proj=proj)
  newdata = sp.to.df(newdata, xnm=xy.names[1], ynm=xy.names[2], proj=proj)
  
  #let AtoP.krige do the actual work:
  res = AtoP.krige.int(data=data, newdata=newdata, xy.names=xy.names, ...)
  
  #convert back to SpatialPointsDataFrame, but without inverting the projection (sorry):
  coordinates(res) = as.formula( paste("~", xy.names[1], "+", xy.names[2]) )
  
  return( res )
}




#' @rdname sp.AtoP.krige
#' @name sp.AtoP.krige.S
#' @export
sp.AtoP.krige.S = function(data, newdata = data, 
                             xy.names = c("x","y"), proj = "+proj=utm +zone=32", ...)
{
  require(sp)
  require(rgdal)
  #only this object class is accepted as an input:
  stopifnot("SpatialPointsDataFrame" %in% class(data))
  stopifnot("SpatialPointsDataFrame" %in% class(newdata))
  
  #conversion and projection function:
  sp.to.df = function(d,xnm,ynm,proj) {
    #convert the lat/lon coordinates to UTM
    prj = project(cbind(coordinates(d)[,1], coordinates(d)[,2]), proj=proj)
    d = as.data.frame(d)
    #add UTM coordinates to the spatial data frame
    d[,xnm] = prj[,1]
    d[,ynm] = prj[,2]
    return(d)
  }
  
  #convert to data.frame, and project to proj:
  data = sp.to.df(data, xnm=xy.names[1], ynm=xy.names[2], proj=proj)
  newdata = sp.to.df(newdata, xnm=xy.names[1], ynm=xy.names[2], proj=proj)
  
  #let AtoP.krige do the actual work:
  res = AtoP.krige.S(data=data, newdata=newdata, xy.names=xy.names, ...)
  
  #convert back to SpatialPointsDataFrame, but without inverting the projection (sorry):
  coordinates(res) = as.formula( paste("~", xy.names[1], "+", xy.names[2]) )
  
  return( res )
}
